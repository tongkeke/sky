export declare class SecureRandom {
    nextBytes(ba: number[]): void;
}
